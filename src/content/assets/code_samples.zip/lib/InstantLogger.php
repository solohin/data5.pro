<?php
require_once(__DIR__.'/vendor/autoload.php');

/**
 * Created by PhpStorm.
 * User: solohin
 * Date: 19.07.16
 * Time: 11:36
 */
use \Psr\Log\AbstractLogger;
use \Psr\Log\LogLevel;

/**
 * Class InstantLogger Хранит логи в переменной
 */
class InstantLogger extends AbstractLogger{
    const LEVEL_INFO = 1;
    const LEVEL_WARNING = 2;
    const LEVEL_ERROR = 3;

    private $log = "";

    /**
     * Logs with an arbitrary level.
     *
     * @param mixed $level
     * @param string $message
     * @param array $context
     * @return null
     */
    public function log($level, $message, array $context = array()) {
        $this->log .= self::getPrefix($level).$message."\n";
    }

    public function getLog($drop = false){
        if($drop){
            $log = $this->log;
            $this->log = '';
            return $log;
        }else{
            return $this->log;
        }
    }

    private static function getPrefix($level){
        if(in_array($level, [LogLevel::ALERT, LogLevel::CRITICAL, LogLevel::EMERGENCY, LogLevel::ERROR])){
            $return = "ERROR";
        }elseif(in_array($level, [LogLevel::WARNING, LogLevel::NOTICE])){
            $return = "WARNING";
        }else{
            $return = "INFO";
        }

        $longest = "WARNING";
        $addSpaces = strlen($longest) - strlen($return);
        $return = $return.str_repeat(' ', $addSpaces);
        return $return;
    }
}
