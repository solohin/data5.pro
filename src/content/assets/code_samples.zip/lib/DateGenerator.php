<?php

/**
 * Created by PhpStorm.
 * User: solohin
 * Date: 15.07.16
 * Time: 15:51
 */
class DateGenerator {
    public static function startOfMonth($sampleTime = null){
        return strtotime('first day of this month midnight', $sampleTime);
    }
    public static function endOfMonth($sampleTime = null){
        return strtotime('last day of this month 23:59:59', $sampleTime);
    }
    public static function startOfWeek($sampleTime = null){
        return strtotime("last monday", strtotime('tomorrow', $sampleTime));
    }
    public static function endOfWeek($sampleTime = null){
        return  strtotime("next monday", $sampleTime) - 1;
    }
    public static function startYesturday($sampleTime = null){
        if(is_null($sampleTime)){
            $sampleTime = time();
        }
        $sampleTime -= 24*60*60;
        return self::startToday($sampleTime);
    }
    public static function endYesterday($sampleTime = null){
        if(is_null($sampleTime)){
            $sampleTime = time();
        }
        $sampleTime -= 24*60*60;
        return self::endToday($sampleTime);
    }
    public static function startToday($sampleTime = null){
        return strtotime('00:00', $sampleTime);
    }
    public static function endToday($sampleTime = null){
        return strtotime('23:59:59', $sampleTime);
    }
}