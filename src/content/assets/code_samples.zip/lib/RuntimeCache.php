<?php

/**
 * Class RuntimeCache
 * For method calls caching
 * Cache key calculates automatically based on name and arguments of caller function
 */
class RuntimeCache{
    private static $instance;
    private $cache = [];

    public function __construct() {
        if(!is_null(self::$instance)){
            throw new RuntimeException('Yo have to use RuntimeCache::getInstance instead of creating new RuntimeCache object');
        }
        self::$instance = $this;
    }

    /**
     * @return RuntimeCache Singleton instance
     */
    public static function getInstance(){
        if (is_null(self::$instance)) {
            self::$instance = new RuntimeCache();
        }
        return self::$instance;
    }

    /**
     * @return bool is caller method result cached
     */
    public function cached(){
        $key = $this->getKey();
        return isset($this->cache[$key]);
    }

    /**
     * @param $value mixed Cached value
     * @return mixed The same value for chaining, ex: return $runtimeCache->cache($result);
     */
    public function cache($value){
        $key = $this->getKey();
        $this->cache[$key] = $value;
        return $value;
    }

    /**
     * @param null|mixed $default Default value if not exists
     * @return mixed Cached value or default
     */
    public function getCached($default = null){
        $key = $this->getKey();
        if(isset($this->cache[$key])){
            return $this->cache[$key];
        }else{
            return $default;
        }
    }

    private function getKey(){
        //TODO speed up!
        $depth = 2;
        $trace = debug_backtrace()[$depth];
        $keyData = [];

        if(isset($trace['args'])) $keyData['args'] = $trace['args'];
        if(isset($trace['function'])) $keyData['function'] = $trace['function'];
        if(isset($trace['class'])) $keyData['class'] = $trace['class'];

        return md5(serialize($keyData));
    }
}