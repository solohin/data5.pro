<?php
/**
 * Created by PhpStorm.
 * User: solohin
 * Date: 25.07.16
 * Time: 10:03
 */

namespace irtikud\QA;


abstract class AbstractStatusTimeChecker extends AbstractChecker{
    protected abstract function getStatusName();
    protected abstract function getMaxStatusTime();

    /**
     * Главная функиця, которая и осуществляет проверку контроля качества
     * @param array $lead
     * @return array Массив с полями
     */
    protected function inspect(array $lead) {
        $amo = $this->getAmo();

        //Вообще стандартно это дата создания сделки
        $leadTransferTS = $amo->leadStatusChangeFirstDate($lead['status_id'], $lead['id'], true);
        if(!$leadTransferTS){
            $leadTransferTS = $lead['date_create'];
        }

        $totalTime = time()-$leadTransferTS;
        $failTime = 0;
        $restTime = 0;

        if($totalTime > $this->getMaxStatusTime()){
            $failTime = $totalTime-$this->getMaxStatusTime();
        }else{
            $restTime = $this->getMaxStatusTime() - $totalTime;
        }

        $isCorrect = ($failTime == 0);

        return [
            'fail_time'=>$failTime,
            'total_time'=>$totalTime,
            'is_correct'=>$isCorrect,
            'rest_time'=>$restTime,
        ];
    }

    /**
     * Провека того что именно этот контроллер должен работать с этой функцией
     * @param array $lead
     * @return boolean Нужна ли проверка
     */
    public function needInspect(array $lead) {
        $amo = $this->getAmo();
        $statusName = $amo->getStatusName($lead['status_id']);
        return mb_strtolower(trim($statusName)) == mb_strtolower(trim($this->getStatusName())) ;
    }
}