<?php
/**
 * Created by PhpStorm.
 * User: solohin
 * Date: 25.07.16
 * Time: 10:03
 */

namespace irtikud\QA;


class InWorkChecker extends AbstractStatusTimeChecker{
    protected function getStatusName() {
        return 'В работе';
    }

    protected function getMaxStatusTime() {
        return 7*24*60*60;
    }
}