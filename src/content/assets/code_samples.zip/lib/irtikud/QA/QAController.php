<?php
namespace irtikud\QA ;
/**
 * Created by PhpStorm.
 * User: solohin
 * Date: 21.07.16
 * Time: 13:22
 */
class QAController{
    const QA_OTHER_SECTIONS_SECONDS = 30*60;
    const CHECKER_NAMES = [
        'NewLeadChecker',
        'RepeatLeadChecker',
        'InWorkChecker',
        'UnderControlChecker',
        'ClosingChecker',
    ];
    private $checkers = [];
    private $emptyChecker = null;

    public function __construct(\amocrmApi $amo, \scibi $bi, $checkerNames = self::CHECKER_NAMES){
        $this->checkers = [];
        foreach($checkerNames as $className){
            $className = __NAMESPACE__.'\\'.$className;
            $this->checkers[] = new $className($amo, $bi);
        }
        $this->emptyChecker = new EmptyChecker($amo, $bi);
    }

    /**
     * Отдает экземляр нужного чекера для проверки результатов функции
     * @param $lead
     * @return AbstractChecker|null
     */
    private function getChecker($lead){
        /** @var AbstractChecker $checker */
        foreach($this->checkers as $checker){
            if($checker->needInspect($lead)){
                return $checker;
            }
        }
        return $this->emptyChecker;
    }

    /**
     * Прововеряет сделку на корректность
     * @param array $lead Сделка для проверки в виде массива
     * @return boolean Верна сделка или нет
     */
    public function isCorrect(array $lead){
        return $this->getChecker($lead)->isCorrect($lead);
    }
    /**
     * Возвращает true или false в зависимости от того был ли применен к сделке хоть один чекер
     * @param array $lead Сделка для проверки в виде массива
     * @return boolean Будет ли пременен чекер или останется EmptyChecker
     */
    public function anyCheckerApplied(array $lead){
        $class = get_class($this->getChecker($lead));
        return $class != __NAMESPACE__.'\\'.'EmptyChecker';
    }

    /**
     * Отдает время просрочки или 0, если оно еще не наступило
     * @param array $lead Сделка для проверки в виде массива
     * @return int Секунды просрочки или 0
     */
    public function getFailTime(array $lead){
        return $this->getChecker($lead)->getFailTime($lead);
    }
    /**
     * Отдает полное время нахождения сделки под условием
     * @param array $lead Сделка для проверки в виде массива
     * @return int Секунды просрочки или 0
     */
    public function getTotalTime(array $lead){
        return $this->getChecker($lead)->getTotalTime($lead);
    }
    /**
     * Отдает оставшееся время
     * @param array $lead Сделка для проверки в виде массива
     * @return int Секунды оставшиеся или 0
     */
    public function getRestTime(array $lead){
        return $this->getChecker($lead)->getRestTime($lead);
    }

    public function getApprovedMaximum(array $lead){
        return $this->getChecker($lead)->getApprovedMaximum($lead);
    }
}