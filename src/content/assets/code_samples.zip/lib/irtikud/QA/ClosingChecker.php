<?php
/**
 * Created by PhpStorm.
 * User: solohin
 * Date: 25.07.16
 * Time: 10:03
 */

namespace irtikud\QA;


class ClosingChecker extends AbstractStatusTimeChecker{
    const DELAY_SECONDS = 7*24*60*60;
    const DELAY_TIMES = 2;

    protected function getStatusName() {
        return 'Закрытие';
    }

    protected function getMaxStatusTime() {
        return 14*24*60*60;
    }

    /**
     * Главная функиця, которая и осуществляет проверку контроля качества
     * @param array $lead
     * @return array Массив с полями
     */
    protected function inspect(array $lead) {
        $return = parent::inspect($lead);

        $delayed = 0;
        $hasTimeDonation = false;

        while(
            $return['fail_time'] > 0
            && $delayed < self::DELAY_TIMES
        ){
            $delayed++;
            $return['fail_time'] -= self::DELAY_SECONDS;
            $hasTimeDonation = true;
        }

        if($return['fail_time'] < 0 && $hasTimeDonation){
            $return['rest_time'] = $return['fail_time'] * -1;
            $return['fail_time'] = 0;
            $return['is_correct'] = true;
        }

        return $return;
    }
}