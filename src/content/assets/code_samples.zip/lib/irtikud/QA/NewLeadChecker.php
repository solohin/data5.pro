<?php
/**
 * Created by PhpStorm.
 * User: solohin
 * Date: 21.07.16
 * Time: 13:43
 */

namespace irtikud\QA;


class NewLeadChecker extends AbstractChecker{
    const NEW_LEAD_TIME = 60*60;

    /**
     * Главная функиця, которая и осуществляет проверку контроля качества
     * @param array $lead
     * @return array Массив с полями
     */
    protected function inspect(array $lead) {
        $amo = $this->getAmo();
        $admin = $amo->getAdminAccountId();

        $history = $amo->getNotesHistoryMongo($lead['id']);

        //Вообще стандартно это дата создания сделки
        $dateCreate = $lead['date_create'];

        //Но если есть заметка, начинающаяся с "Перевод сделки" от админа, то она перезаписывает дату создания сделки
        foreach ($history as $item) {
            if(
                $item['created_user_id'] == $admin
                && mb_stripos($item['text'], 'Перевод сделки') === 0
            ){
                $dateCreate = $item['date_create'];
            }
        }

        $totalTime = time()-$dateCreate;
        $failTime = 0;
        $restTime = 0;

        if($totalTime > self::NEW_LEAD_TIME){
            $failTime = $totalTime-self::NEW_LEAD_TIME;
        }else{
            $restTime = self::NEW_LEAD_TIME - $totalTime;
        }

        $isCorrect = ($failTime == 0);

        return [
            'fail_time'=>$failTime,
            'total_time'=>$totalTime,
            'is_correct'=>$isCorrect,
            'rest_time'=>$restTime,
        ];
    }

    /**
     * Провека того что именно этот контроллер должен работать с этой функцией
     * @param array $lead
     * @return boolean Нужна ли проверка
     */
    public function needInspect(array $lead) {
        $amo = $this->getAmo();
        $admin = $amo->getAdminAccountId();

        return (
            $amo->getStatusNumber($lead['status_id']) == 1
            && $lead['responsible_user_id'] != $admin
        );
    }
}