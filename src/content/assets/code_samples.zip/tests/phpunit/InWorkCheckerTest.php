<?php
use irtikud\QA\InWorkChecker;

/**
 * Created by PhpStorm.
 * User: solohin
 * Date: 21.07.16
 * Time: 15:12
 */
class InWorkCheckerTest extends PHPUnit_Framework_TestCase {
    private $amo;

    const IN_WORK_TIME = 7*24*60*60;
    const OUR_STATUS_NAME = 'В работе';
    const OTHER_STATUS_NAME = 'non-interesting status***';
    const OUR_STATUS_ID = 999;
    const OTHER_STATUS_ID = 777;

    public function testIncorrectStatus() {
        $inWorkChecker = $this->newInstance();
        $lead = $this->getLead(['status_id' => self::OTHER_STATUS_ID]);
        $this->assertFalse($inWorkChecker->needInspect($lead));
    }

    public function testCorrectStatus() {
        $inWorkChecker = $this->newInstance();
        $lead = $this->getLead();
        $this->assertTrue($inWorkChecker->needInspect($lead));
    }

    public function testFormat() {
        $newLeadChecker = $this->newInstance();

        $lead = $this->getLead();

        $newLeadChecker->isCorrect($lead);
        $newLeadChecker->getFailTime($lead);
        $newLeadChecker->getTotalTime($lead);
        $newLeadChecker->getRestTime($lead);
    }

    public function testOutdated(){
        $newLeadChecker = $this->newInstance([
            'first_status_move_ts' => time()-self::IN_WORK_TIME-1,
        ]);
        $lead = $this->getLead();

        $this->assertTrue($newLeadChecker->needInspect($lead));

        $this->assertFalse($newLeadChecker->isCorrect($lead), 'in isCorrect');
        $this->assertEquals($newLeadChecker->getFailTime($lead),1,'in getFailTime');
        $this->assertEquals($newLeadChecker->getTotalTime($lead),self::IN_WORK_TIME+1,'in getTotalTime');
        $this->assertEquals($newLeadChecker->getRestTime($lead),0,'in getRestTime');
    }

    public function testOkDate(){
        $newLeadChecker = $this->newInstance([
            'first_status_move_ts' => time()-self::IN_WORK_TIME+1,
        ]);
        $lead = $this->getLead();

        $this->assertTrue($newLeadChecker->needInspect($lead));

        $this->assertTrue($newLeadChecker->isCorrect($lead));
        $this->assertEquals($newLeadChecker->getFailTime($lead),0);
        $this->assertEquals($newLeadChecker->getTotalTime($lead),self::IN_WORK_TIME-1);
        $this->assertEquals($newLeadChecker->getRestTime($lead),1);
    }

    private function getLead(array $overrideFields = []){
        $lead = array_merge([
            'id' => 12345,
            'status_id' => self::OUR_STATUS_ID,
        ], $overrideFields);
        return $lead;
    }

    /**
     * @param $configParam
     * @return InWorkChecker
     */
    private function newInstance(array $configParam = []) {
        $config = array_merge(
            [
                'first_status_move_ts' => time(),
                'last_status_move_ts' => time(),
            ], $configParam
        );

        $this->amo = $this->getMockBuilder(amocrmApi::class)
            ->disableOriginalConstructor()
            ->getMock();

        $this->amo->expects($this->any())->method('getStatusName')->will(
            $this->returnCallback(array($this, 'amocrmApi__getStatusName'))
        );
        $this->amo->expects($this->any())->method('leadStatusChangeFirstDate')->will(
            $this->returnCallback(function($statusId) use ($config){
                $moves = $this->createStatusMoves($config['first_status_move_ts'], $config['last_status_move_ts']);
                $order = 1;

                usort($moves, function($a, $b) use ($order){
                    return $order * strcmp($a["timestamp"], $b["timestamp"]);
                });

                foreach($moves as $move){
                    if($move['new'] == $statusId){
                        return $move['timestamp'];
                    }
                }

                return false;
            })
        );
        $this->amo->expects($this->any())->method('getStatusMoves')->will(
            $this->returnValue(
                $this->createStatusMoves($config['first_status_move_ts'], $config['last_status_move_ts'])
            )
        );

        $bi = $this->getMockBuilder(scibi::class)->disableOriginalConstructor()->getMock();

        $instance = new InWorkChecker($this->amo, $bi);
        return $instance;
    }

    public function amocrmApi__getStatusName($id) {
        switch($id){
            case self::OUR_STATUS_ID:
                return self::OUR_STATUS_NAME;
                break;
            case self::OTHER_STATUS_ID:
                return self::OTHER_STATUS_NAME;
                break;
            default:
                return self::OTHER_STATUS_NAME;
        }
    }

    private function createStatusMoves($firstTime, $lastTime){
        $history = [];
        $history[] = [
            'old' => self::OTHER_STATUS_ID,
            'new' => self::OUR_STATUS_ID,
            'timestamp' => $firstTime,
        ];
        $history[] = [
            'old' => self::OUR_STATUS_ID,
            'new' => self::OTHER_STATUS_ID,
            'timestamp' => $firstTime+1,
        ];
        $history[] = [
            'old' => self::OTHER_STATUS_ID,
            'new' => self::OUR_STATUS_ID,
            'timestamp' => $lastTime,
        ];
        usort($history, function($a, $b){
            return strcmp($a["timestamp"], $b["timestamp"]);
        });
        return $history;
    }

}