<?php
use irtikud\QA\NewLeadChecker;

/**
 * Created by PhpStorm.
 * User: solohin
 * Date: 21.07.16
 * Time: 15:12
 */
class NewLeadCheckerTest extends PHPUnit_Framework_TestCase {
    const NEW_LEAD_TIME = 60*60;
    private $adminId;

    public function testIncorrectStatus1() {
        $newLeadChecker = $this->newInstance(1);

        $lead = $this->getLead(time(), true);

        $this->assertFalse($newLeadChecker->needInspect($lead));
    }

    public function testIncorrectStatus2() {
        $newLeadChecker = $this->newInstance(rand(2,100));

        $lead = $this->getLead(time(), true);

        $this->assertFalse($newLeadChecker->needInspect($lead));
    }

    public function testCorrectStatus() {
        $newLeadChecker = $this->newInstance(1);

        $lead = $this->getLead(time(), false);

        $this->assertTrue($newLeadChecker->needInspect($lead));
    }

    public function testFormat() {
        $newLeadChecker = $this->newInstance(1);

        $lead = $this->getLead(time(), false);

        $newLeadChecker->isCorrect($lead);
        $newLeadChecker->getFailTime($lead);
        $newLeadChecker->getTotalTime($lead);
        $newLeadChecker->getRestTime($lead);
    }

    public function testOutdated(){
        $newLeadChecker = $this->newInstance(1);
        $lead = $this->getLead(time() - self::NEW_LEAD_TIME - 1, false);

        $this->assertTrue($newLeadChecker->needInspect($lead));

        $this->assertFalse($newLeadChecker->isCorrect($lead));
        $this->assertEquals($newLeadChecker->getFailTime($lead),1);
        $this->assertEquals($newLeadChecker->getTotalTime($lead),self::NEW_LEAD_TIME+1);
        $this->assertEquals($newLeadChecker->getRestTime($lead),0);
    }

    public function testOkDate(){
        $newLeadChecker = $this->newInstance(1);
        $lead = $this->getLead(time() - self::NEW_LEAD_TIME + 1, false);

        $this->assertTrue($newLeadChecker->needInspect($lead));

        $this->assertTrue($newLeadChecker->isCorrect($lead));
        $this->assertEquals($newLeadChecker->getFailTime($lead),0);
        $this->assertEquals($newLeadChecker->getTotalTime($lead),self::NEW_LEAD_TIME-1);
        $this->assertEquals($newLeadChecker->getRestTime($lead),1);
    }

    private function getLead($dateCreate, $responsibleIsAdmin){
        $lead = [
            'id' => '1234567890123',
            'date_create' => $dateCreate,
            'responsible_user_id' => $this->adminId + !($responsibleIsAdmin),
            'status_id' => 0,
        ];
        return $lead;
    }

    public function setUp(){
        $this->adminId = rand(0,10000000);
    }

    private function newInstance($returnStatusNumber, $history = []) {
        $amo = $this->getMockBuilder(amocrmApi::class)->disableOriginalConstructor()->getMock();

        $amo->expects($this->any())->method('getStatusNumber')->will($this->returnValue($returnStatusNumber));
        $amo->expects($this->any())->method('getAdminAccountId')->will($this->returnValue($this->adminId));
        $amo->expects($this->any())->method('getNotesHistory')->will($this->returnValue($history));
        $amo->expects($this->any())->method('getNotesHistoryMongo')->will($this->returnValue($history));

        $bi = $this->getMockBuilder(scibi::class)->disableOriginalConstructor()->getMock();

        $instance = new NewLeadChecker($amo, $bi);
        return $instance;
    }


}