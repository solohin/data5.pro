<?php
/**
 * Created by PhpStorm.
 * User: solohin
 * Date: 18.07.16
 * Time: 17:50
 */

class RuntimeCacheTest extends PHPUnit_Framework_TestCase{
    private $results = [];
    private $methodCallsCount = 0;

    const TEST_RESULT = 'This is test result';

    public function testmethodCallsCountCount(){
        $this->assertEquals($this->methodCallsCount,0);
        
        $this->methodCall(['here is an object'], 'test');
        $this->assertEquals($this->methodCallsCount,1);

        $this->methodCall(['here is an object'], 'test');
        $this->assertEquals($this->methodCallsCount,1);

        $this->methodCall('different parameters');
        $this->assertEquals($this->methodCallsCount,2);

        $this->methodCall('different parameters');
        $this->assertEquals($this->methodCallsCount,2);
    }

    public function testCacheEquality(){
        $result1 = $this->methodCall(['here is an object'], 'test');
        $result2 = $this->methodCall(['here is an object'], 'test');

        $this->assertEquals($result1, $result2);

        $result3 = $this->methodCall('different parameters');

        $this->assertNotEquals($result1, $result3);
    }

    private function methodCall($param1, $param2 = false){
        $runtimeCache = RuntimeCache::getInstance();
        
        if($runtimeCache->cached()){
            return $runtimeCache->getCached();
        }

        do{
            $result = time().rand(0, 1000000);
        }while(in_array($result, $this->results));

        $this->results[] = $result;
        $this->methodCallsCount++;

        return $runtimeCache->cache($result);
    }

    public function setUp(){
        $this->methodCallsCount = 0;
        $this->results = [];
    }
}