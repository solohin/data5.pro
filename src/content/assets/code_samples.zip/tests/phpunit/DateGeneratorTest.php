<?php
/**
 * Created by PhpStorm.
 * User: solohin
 * Date: 20.07.16
 * Time: 16:28
 */

class DateGeneratorTest extends PHPUnit_Framework_TestCase{
    const TEST_TIMESTAMP1 = 1455539400;//Mon, 15 Feb 2016 15:30:00 +0300
    const TEST_TIMESTAMP2 = 1456057800;//Sun, 21 Feb 2016 15:30:00 +0300

    public function testMonth(){
        $startTimestamp1 =  DateGenerator::startOfMonth(self::TEST_TIMESTAMP1);
        $endTimestamp1 =  DateGenerator::endOfMonth(self::TEST_TIMESTAMP1);
        $startTimestamp2 =  DateGenerator::startOfMonth(self::TEST_TIMESTAMP2);
        $endTimestamp2 =  DateGenerator::endOfMonth(self::TEST_TIMESTAMP2);

        $this->assertEquals(DateFormatter::russianDateTime($startTimestamp1), '00:00,  1 ФЕВ 2016');
        $this->assertEquals(DateFormatter::russianDateTime($endTimestamp1), '23:59, 29 ФЕВ 2016');

        $this->assertEquals(DateFormatter::russianDateTime($startTimestamp2), '00:00,  1 ФЕВ 2016');
        $this->assertEquals(DateFormatter::russianDateTime($endTimestamp2), '23:59, 29 ФЕВ 2016');
    }

    public function testWeek(){
        $startTimestamp1 =  DateGenerator::startOfWeek(self::TEST_TIMESTAMP1);
        $endTimestamp1 =  DateGenerator::endOfWeek(self::TEST_TIMESTAMP1);
        $startTimestamp2 =  DateGenerator::startOfWeek(self::TEST_TIMESTAMP2);
        $endTimestamp2 =  DateGenerator::endOfWeek(self::TEST_TIMESTAMP2);

        $this->assertEquals(DateFormatter::russianDateTime($startTimestamp1), '00:00, 15 ФЕВ 2016');
        $this->assertEquals(DateFormatter::russianDateTime($endTimestamp1), '23:59, 21 ФЕВ 2016');
        $this->assertEquals(DateFormatter::russianDateTime($startTimestamp2), '00:00, 15 ФЕВ 2016');
        $this->assertEquals(DateFormatter::russianDateTime($endTimestamp2), '23:59, 21 ФЕВ 2016');
    }
    public function testYesterday(){
        $startTimestamp1 =  DateGenerator::startYesturday(self::TEST_TIMESTAMP1);
        $endTimestamp1 =  DateGenerator::endYesterday(self::TEST_TIMESTAMP1);
        $startTimestamp2 =  DateGenerator::startYesturday(self::TEST_TIMESTAMP2);
        $endTimestamp2 =  DateGenerator::endYesterday(self::TEST_TIMESTAMP2);

        $this->assertEquals(DateFormatter::russianDateTime($startTimestamp1), '00:00, 14 ФЕВ 2016');
        $this->assertEquals(DateFormatter::russianDateTime($endTimestamp1), '23:59, 14 ФЕВ 2016');
        $this->assertEquals(DateFormatter::russianDateTime($startTimestamp2), '00:00, 20 ФЕВ 2016');
        $this->assertEquals(DateFormatter::russianDateTime($endTimestamp2), '23:59, 20 ФЕВ 2016');
    }
    public function testToday(){
        $startTimestamp1 =  DateGenerator::startToday(self::TEST_TIMESTAMP1);
        $endTimestamp1 =  DateGenerator::endToday(self::TEST_TIMESTAMP1);
        $startTimestamp2 =  DateGenerator::startToday(self::TEST_TIMESTAMP2);
        $endTimestamp2 =  DateGenerator::endToday(self::TEST_TIMESTAMP2);

        $this->assertEquals(DateFormatter::russianDateTime($startTimestamp1), '00:00, 15 ФЕВ 2016');
        $this->assertEquals(DateFormatter::russianDateTime($endTimestamp1), '23:59, 15 ФЕВ 2016');
        $this->assertEquals(DateFormatter::russianDateTime($startTimestamp2), '00:00, 21 ФЕВ 2016');
        $this->assertEquals(DateFormatter::russianDateTime($endTimestamp2), '23:59, 21 ФЕВ 2016');
    }
}